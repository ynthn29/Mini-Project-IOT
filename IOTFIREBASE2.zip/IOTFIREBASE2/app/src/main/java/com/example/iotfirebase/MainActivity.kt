package com.example.iotfirebase

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ldr = findViewById<TextView>(R.id.ldr)
        val lampstatus = findViewById<TextView>(R.id.lampstatus)

        val dref = FirebaseDatabase.getInstance("https://yonathaniot-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference()

        dref.addValueEventListener(object:ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val valueLdr = dataSnapshot.child("/ldr").getValue().toString()
                ldr.setText(valueLdr)
                val valueLampStatus = dataSnapshot.child("/lampstatus").getValue().toString()
                lampstatus.setText(valueLampStatus)

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })

    }
}